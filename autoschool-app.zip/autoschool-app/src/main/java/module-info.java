module org.main.autoschool {
    requires javafx.controls;
    requires javafx.fxml;
    requires jakarta.persistence;
    requires org.hibernate.orm.core;
    requires java.naming;
    requires java.desktop;
    requires javafx.swing;
    requires org.hibernate.validator;
    requires org.postgresql.jdbc;
    requires jakarta.validation;
    requires itextpdf;

    opens org.main.autoschoolapp to javafx.fxml;
    opens org.main.autoschoolapp.model to org.hibernate.orm.core;
    exports org.main.autoschoolapp;
    exports org.main.autoschoolapp.model;
    opens org.main.autoschoolapp.util to org.hibernate.orm.core;
    exports org.main.autoschoolapp.controller.edits;
    opens org.main.autoschoolapp.controller.edits to javafx.fxml;
    exports org.main.autoschoolapp.controller.cell;
    opens org.main.autoschoolapp.controller.cell to javafx.fxml;
    exports org.main.autoschoolapp.controller.view;
    opens org.main.autoschoolapp.controller.view to javafx.fxml;
    exports org.main.autoschoolapp.authorization;
    opens org.main.autoschoolapp.authorization to javafx.fxml;

}