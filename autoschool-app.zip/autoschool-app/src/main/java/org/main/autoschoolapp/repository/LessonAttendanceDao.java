package org.main.autoschoolapp.repository;

import org.main.autoschoolapp.model.LessonAttendance;

public class LessonAttendanceDao extends BaseDao<LessonAttendance> {
    public LessonAttendanceDao() {
        super(LessonAttendance.class);
    }
}
