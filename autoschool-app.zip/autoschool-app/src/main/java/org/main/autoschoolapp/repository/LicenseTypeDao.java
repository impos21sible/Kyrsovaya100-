package org.main.autoschoolapp.repository;

import org.main.autoschoolapp.model.LicenseType;


public class LicenseTypeDao extends BaseDao<LicenseType> {
    public LicenseTypeDao() {
        super(LicenseType.class);
    }
}

