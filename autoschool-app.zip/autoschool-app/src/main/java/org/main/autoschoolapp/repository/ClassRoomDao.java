package org.main.autoschoolapp.repository;

import org.main.autoschoolapp.model.ClassRoom;

public class ClassRoomDao extends BaseDao<ClassRoom> {
    public ClassRoomDao() {
        super(ClassRoom.class);
    }
}
